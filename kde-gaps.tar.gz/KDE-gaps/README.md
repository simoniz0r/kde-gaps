---
title: Home
layout: discorddownloader
permalink: /README.md
---

![kde-gaps](https://raw.githubusercontent.com/simoniz0r/index/master/KDE-gaps.png)

### A modification of [Arc-Dark by varlesh](https://github.com/varlesh/) that removes the title, window buttons, and makes the window decorations completely transparent.  KDE-gaps is setup to have a 10px gap between windows to simulate the look of a tiling Window Manager.

### [Download KDE-gaps](https://github.com/simoniz0r/kde-gaps/releases/latest)
